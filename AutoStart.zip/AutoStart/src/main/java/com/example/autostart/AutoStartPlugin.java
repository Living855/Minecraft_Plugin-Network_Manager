com.example.autostart;

import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.ProxyServer;
import net.md_5.bungee.api.config.ServerInfo;
import net.md_5.bungee.api.connection.ProxiedPlayer;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.api.plugin.Plugin;
import net.md_5.bungee.config.Configuration;
import net.md_5.bungee.config.YamlConfiguration;
import net.md_5.bungee.event.EventHandler;

import javax.net.ssl.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class AutoStartPlugin extends Plugin implements Listener {

    private Configuration config;
    private String apiBaseUrl;
    private String apiKey;
    // Map of managed servers keyed by server name (lowercase).
    private Map<String, ManagedServer> managedServers = new HashMap<>();
    // Refresh interval (in seconds) to update the server list from the API.
    private int refreshIntervalSeconds;

    @Override
    public void onEnable() {
        getLogger().info("Enabling AutoStartPlugin...");
        loadConfiguration();
        loadManagedServers();
        // Schedule periodic updates of the managed servers list.
        ProxyServer.getInstance().getScheduler().schedule(this, this::loadManagedServers, refreshIntervalSeconds, refreshIntervalSeconds, TimeUnit.SECONDS);
        getProxy().getPluginManager().registerListener(this, this);
        getLogger().info("AutoStartPlugin enabled successfully. Managed servers: " + managedServers.keySet());
    }

    private void loadConfiguration() {
        getLogger().info("Loading configuration...");
        // Ensure plugin folder exists
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().severe("Failed to create plugin data folder!");
        }
        File configFile = new File(getDataFolder(), "config.yml");
        if (!configFile.exists()) {
            getLogger().info("No config.yml found. Creating default config...");
            try (OutputStream out = new FileOutputStream(configFile)) {
                String defaultConfig =
                        "api:\n" +
                        "  baseUrl: \"https://192.168.29.167:25560\"\n" +
                        "  apiKey: \"your_api_key_here\"\n" +
                        "refreshIntervalSeconds: 300\n";
                out.write(defaultConfig.getBytes(StandardCharsets.UTF_8));
                getLogger().info("Default config.yml created.");
            } catch (IOException e) {
                getLogger().severe("Failed to create default config.yml: " + e.getMessage());
            }
        }
        try {
            config = YamlConfiguration.getProvider(YamlConfiguration.class).load(configFile);
            apiBaseUrl = config.getString("api.baseUrl");
            apiKey = config.getString("api.apiKey");
            refreshIntervalSeconds = config.getInt("refreshIntervalSeconds", 300);
            getLogger().info("Configuration loaded: apiBaseUrl=" + apiBaseUrl + ", refreshIntervalSeconds=" + refreshIntervalSeconds);
        } catch (IOException e) {
            getLogger().severe("Failed to load config.yml: " + e.getMessage());
        }
    }

    /**
     * Refreshes the list of managed servers by querying the MCSS API.
     * Expects the API endpoint GET {apiBaseUrl}/api/v2/servers to return a JSON array of server objects.
     */
    private void loadManagedServers() {
        getLogger().info("Refreshing managed servers list from API...");
        try {
            URL url = new URL(apiBaseUrl + "/api/v2/servers");
            // If using HTTPS, disable certificate verification (for testing only)
            if (url.getProtocol().equalsIgnoreCase("https")) {
                disableSslVerification();
            }
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // Use the header name "apiKey" as required by the API.
            conn.setRequestProperty("apiKey", apiKey);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            int responseCode = conn.getResponseCode();
            getLogger().info("Managed servers API response code: " + responseCode);
            if (responseCode >= 200 && responseCode < 300) {
                String response = readStream(conn.getInputStream());
                getLogger().info("Managed servers API response: " + response);
                List<ManagedServer> list = parseServers(response);
                synchronized (managedServers) {
                    managedServers.clear();
                    for (ManagedServer s : list) {
                        managedServers.put(s.getServerName().toLowerCase(), s);
                    }
                }
                getLogger().info("Managed servers updated: " + managedServers.keySet());
            } else {
                getLogger().warning("Failed to refresh managed servers. API returned response code: " + responseCode);
            }
        } catch (IOException e) {
            getLogger().severe("Error refreshing managed servers: " + e.getMessage());
        }
    }

    // Reads an InputStream and returns its contents as a String.
    private String readStream(InputStream in) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder builder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            builder.append(line);
        }
        return builder.toString();
    }

    /**
     * Parses the JSON response from the /api/v2/servers endpoint.
     * Expected JSON format: a JSON array of server objects.
     * Each server object should contain at least "serverId" and "name" keys.
     */
    private List<ManagedServer> parseServers(String json) {
        List<ManagedServer> list = new ArrayList<>();
        try {
            json = json.trim();
            if (!json.startsWith("[") || !json.endsWith("]")) {
                getLogger().warning("Expected JSON array for servers, but got: " + json);
                return list;
            }
            String arrayContent = json.substring(1, json.length() - 1).trim();
            if (arrayContent.isEmpty()) {
                getLogger().info("Servers array is empty.");
                return list;
            }
            // Split objects by "},{" pattern.
            String[] entries = arrayContent.split("\\},\\s*\\{");
            for (String entry : entries) {
                if (!entry.startsWith("{")) {
                    entry = "{" + entry;
                }
                if (!entry.endsWith("}")) {
                    entry = entry + "}";
                }
                String serverName = extractJsonValue(entry, "name");
                String serverId = extractJsonValue(entry, "serverId");
                if (serverName != null && serverId != null) {
                    list.add(new ManagedServer(serverName, serverId));
                    getLogger().info("Parsed managed server: " + serverName + " (ID: " + serverId + ")");
                } else {
                    getLogger().warning("Failed to parse an entry: " + entry);
                }
            }
        } catch (Exception e) {
            getLogger().severe("Error parsing servers JSON: " + e.getMessage());
        }
        return list;
    }
    
    // Helper method to extract a value from a JSON-like string.
    private String extractJsonValue(String json, String key) {
        try {
            String searchKey = "\"" + key + "\":";
            int index = json.indexOf(searchKey);
            if (index == -1) return null;
            int valueStart = json.indexOf("\"", index + searchKey.length());
            int valueEnd = json.indexOf("\"", valueStart + 1);
            if (valueStart == -1 || valueEnd == -1) return null;
            return json.substring(valueStart + 1, valueEnd);
        } catch (Exception e) {
            return null;
        }
    }

    @EventHandler
    public void onServerConnect(final ServerConnectEvent event) {
        String targetName = event.getTarget().getName().toLowerCase();
        ManagedServer managed;
        synchronized (managedServers) {
            managed = managedServers.get(targetName);
        }
        if (managed == null) {
            getLogger().info("Player " + event.getPlayer().getName() + " is connecting to unmanaged server: " + targetName);
            return;
        }
        ProxiedPlayer player = event.getPlayer();
        getLogger().info("Player " + player.getName() + " is connecting to managed server: " + targetName);

        // Use API status check instead of checking if the player list is empty.
        if (!isServerOnline(managed.getServerId())) {
            getLogger().info("Server " + targetName + " appears offline according to API. Cancelling connection.");
            event.setCancelled(true);
            player.sendMessage(ChatColor.YELLOW + "Server " + targetName + " is offline. Starting it now. Please wait.");
            getLogger().info("Sending start request for server " + targetName);
            boolean started = sendStartRequest(managed.getServerId());
            if (!started) {
                getLogger().severe("Start request for server " + targetName + " failed.");
                player.sendMessage(ChatColor.RED + "Failed to start the server. Please try again later.");
                return;
            }
            pollForServerOnline(player, targetName, managed.getServerId(), 0);
        } else {
            getLogger().info("Server " + targetName + " is online. Allowing connection.");
            // Allow connection by not cancelling the event.
        }
    }

    /**
     * Sends a start request to the MCSS API for a specific server.
     * Uses the endpoint POST {apiBaseUrl}/api/v2/servers/{serverId}/execute/action
     * with a JSON payload: {"action": 2} (2 = Start).
     */
    private boolean sendStartRequest(String serverId) {
        try {
            URL url = new URL(apiBaseUrl + "/api/v2/servers/" + serverId + "/execute/action");
            if (url.getProtocol().equalsIgnoreCase("https")) {
                disableSslVerification();
            }
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            // Use the header name "apiKey" as required.
            conn.setRequestProperty("apiKey", apiKey);
            conn.setDoOutput(true);
            String jsonPayload = "{\"action\": 2}";
            getLogger().info("Sending start request with payload: " + jsonPayload);
            try (OutputStream os = conn.getOutputStream()) {
                os.write(jsonPayload.getBytes(StandardCharsets.UTF_8));
            }
            int responseCode = conn.getResponseCode();
            getLogger().info("Start request response code: " + responseCode);
            String responseBody = readStream(conn.getInputStream());
            getLogger().info("Start request response body: " + responseBody);
            return responseCode >= 200 && responseCode < 300;
        } catch (IOException e) {
            getLogger().severe("Error sending start request: " + e.getMessage());
            return false;
        }
    }

    private void pollForServerOnline(final ProxiedPlayer player, final String serverName, final String serverId, final int attempt) {
        int maxPollAttempts = 30;
        getLogger().info("Polling for server " + serverName + " status, attempt " + attempt);
        if (attempt >= maxPollAttempts) {
            getLogger().severe("Maximum polling attempts reached for server " + serverName);
            player.sendMessage(ChatColor.RED + "Server did not start in time. Please try again later.");
            return;
        }
        ProxyServer.getInstance().getScheduler().runAsync(this, () -> {
            boolean online = isServerOnline(serverId);
            getLogger().info("Polled server " + serverName + " status: " + (online ? "online" : "offline"));
            if (online) {
                // Before connecting, test the actual network connection.
                ServerInfo target = getProxy().getServerInfo(serverName);
                if (target == null) {
                    getLogger().severe("ServerInfo for " + serverName + " not found!");
                    return;
                }
                SocketAddress socketAddress = target.getSocketAddress();
                if (!(socketAddress instanceof InetSocketAddress)) {
                    getLogger().severe("Socket address is not an instance of InetSocketAddress: " + socketAddress);
                    return;
                }
                InetSocketAddress address = (InetSocketAddress) socketAddress;
                try (Socket socket = new Socket()) {
                    socket.connect(address, 2000);
                    getLogger().info("Connection test to " + address + " succeeded. Connecting player " + player.getName());
                    // Now safely connect the player.
                    ProxyServer.getInstance().getScheduler().runAsync(this, () -> {
                        player.connect(target);
                    });
                } catch (IOException e) {
                    getLogger().warning("Connection test to " + address + " failed: " + e.getMessage());
                    // If connection fails, wait and poll again.
                    ProxyServer.getInstance().getScheduler().schedule(this, () -> {
                        pollForServerOnline(player, serverName, serverId, attempt + 1);
                    }, 2000, TimeUnit.MILLISECONDS);
                }
            } else {
                ProxyServer.getInstance().getScheduler().schedule(this, () -> {
                    pollForServerOnline(player, serverName, serverId, attempt + 1);
                }, 2000, TimeUnit.MILLISECONDS);
            }
        });
    }

    /**
     * Checks the server status via the API endpoint GET {apiBaseUrl}/api/v2/servers/{serverId}/stats.
     * Assumes a 200-299 response indicates the server is online.
     * Additionally, if the JSON response indicates "startDate":0, the server is considered offline.
     */
    private boolean isServerOnline(String serverId) {
        try {
            URL url = new URL(apiBaseUrl + "/api/v2/servers/" + serverId + "/stats");
            if (url.getProtocol().equalsIgnoreCase("https")) {
                disableSslVerification();
            }
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // Use "apiKey" header here as well.
            conn.setRequestProperty("apiKey", apiKey);
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            int responseCode = conn.getResponseCode();
            getLogger().info("Status check response code for serverId " + serverId + ": " + responseCode);
            if (responseCode >= 200 && responseCode < 300) {
                String response = readStream(conn.getInputStream());
                getLogger().info("Status check response body: " + response);
                // If the "startDate" field is zero, assume the server is not truly online.
                if (response.contains("\"startDate\":0")) {
                    return false;
                }
                return true;
            }
        } catch (IOException e) {
            getLogger().severe("Error checking server status for serverId " + serverId + ": " + e.getMessage());
        }
        return false;
    }

    /**
     * Disables SSL certificate verification.
     * WARNING: This should only be used for testing purposes!
     */
    private void disableSslVerification() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                    public void checkClientTrusted(X509Certificate[] certs, String authType) { }
                    public void checkServerTrusted(X509Certificate[] certs, String authType) { }
                }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
            HttpsURLConnection.setDefaultHostnameVerifier((hostname, session) -> true);
            getLogger().info("SSL certificate validation disabled (for testing only).");
        } catch (Exception e) {
            getLogger().severe("Failed to disable SSL verification: " + e.getMessage());
        }
    }

    // Simple POJO for holding managed server data.
    private static class ManagedServer {
        private final String serverName;
        private final String serverId;

        public ManagedServer(String serverName, String serverId) {
            this.serverName = serverName;
            this.serverId = serverId;
        }

        public String getServerName() {
            return serverName;
        }

        public String getServerId() {
            return serverId;
        }
    }
}